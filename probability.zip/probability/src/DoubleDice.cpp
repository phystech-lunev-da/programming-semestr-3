
#include "DoubleDice.hpp"

DoubleDice::DoubleDice(Dice& dice) : dice(dice) {}